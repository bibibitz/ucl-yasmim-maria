class Cliente
{
    private string Nome;

    public Cliente(string Nome)
    {
    this.Nome = Nome;
    }
   public string getNome()
    {
    return Nome;
    }
   public void setNome(string n)
   {
   Nome = n.ToUpper();
   }
}
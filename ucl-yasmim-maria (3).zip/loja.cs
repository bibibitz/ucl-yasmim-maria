class Loja
{
  private List<Doce> estoqueDoces = new List<Doce>();
  private List<Bebida> estoqueBebidas = new List<Bebidas>();
  private List<Salgado> estoqueSalgados = new List<Salgado>();
  public int quantidade;
  
  public Loja()
  {
    //estoque de doces
    estoqueDoces.Add(new Doce("Croissant 🥐", 8));
    estoqueDoces.Add(new Doce("Donut 🍩", 5));
    estoqueDoces.Add(new Doce("Cupcake 🧁", 5));
    estoqueDoces.Add(new Doce("Bolo(fatia) 🍰",10));
    estoqueDoces.Add(new Doce("Tortas 🥧", 10));
    estoqueDoces.Add(new Doce("Pudim 🍮", 6"));

    //estoque de bebidas
    estoqueBebidas.Add(new Bebida("Água Mineral 🫗 ",3));
    estoqueBebidas.Add(new Bebida("Refrigerante 🥤 ",5));
    estoqueBebidas.Add(new Bebida("Sucos 🧃 ", 5));
    estoqueBebidas.Add(new Bebida("Café ☕ ",3));
    estoqueBebidas.Add(new Bebida("Capuccino 🧋 ",7));
    estoqueBebidas.Add(new Bebida("Soda Italiana 🍹 ",10));

    //estoque de salgados
    estoqueSalgados.Add(new Salgado("Coxinha 🌰 ", 6));
    estoqueSalgados.Add(new Salgados("Pão de queijo 🫓 ", 4));
    estoqueSalgados.Add(new Salgados("Empada 🥟 ",5));
    
  } 

  public void ExibirDoces()
  {
    Console.WriteLine("Doces Disponíveis:");
    for (int i = 0; i <estoqueDoces.Count; i++)
    {
        var doce = estoqueDoces[i];
        Console.WriteLine($"{i + 1"}. {doce.getNomeDoce()} - R$ {doce.getPrecoDoce()}");
    }
  }

  public void ExibirBebidas()
{
    Console.WriteLine("Bebidas Disponíveis:");

}

  
  
}
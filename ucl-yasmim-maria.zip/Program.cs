using System;
using System.Collections.Generic;

class Program
{
   static void Main(string[] args)
  {
       string opcaoinicial = "";
       Cliente MeuCliente;
       int quantidadeBebidas;
       int quantidadeDoces;
       int quantidadeSalgados;

       Loja loja = new Loja();

       Console.WriteLine("°°°°°°°°°°°°°°°°°°°°°°   Bem-vindo à  °°°°°°°°°°°°°°°°°°°°°°°");
       Console.WriteLine("°°°°°°°°°°°°°°°°°°°°   Docinhos de Amor  °°°°°°°°°°°°°°°°°°°°");

       Console.Write("Digite o nome do cliente: ");
       string nomeCliente = Console.ReadLine();
       MeuCliente = new Cliente(nomeCliente);

       Pedido pedido = loja.CriarPedido(MeuCliente);

       while (opcaoinicial != "0")
       {
          Console.WriteLine("°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°");
          Console.WriteLine("Escolha uma opção:");
          Console.WriteLine("0. Fechar cardápio do amor");
          Console.WriteLine("1. Abrir cardapinho");
          Console.WriteLine("°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°");
          string opcao = Console.ReadLine();
          string opcaoVoltar = "s";

          switch (opcao)
          {
          case"0":
              Console.WriteLine("Finalizando o pedido...");
              Console.WriteLine("Escolha o método de pagamento:");
              Console.WriteLine("1. Cartão de Crédito");
              Console.WriteLine("2. Cartão de Débito");
              Console.WriteLine("3. Dinheiro");
              int metodoPagamento = int.Parse(Console.ReadLine();

              switch (metodoPagamento)
              {
              case 1:
                  pedido.SetMetodoPagamento("Cartão de Crédito");
                  break;
              case 2:
                  pedido.SetMetodoPagamento("Cartão de Débito");
                  break;
              case 3
                pedido.SetMetodoPagamento("Dinheiro");
                break;
              default: 
                  Console.WriteLine("Método de pagamento inválido. Usando Dinheiro como padrão.");
                  pedido.SetMetodoPagamento("Dinheiro");
                  break;
              }
              pedido.CalcularTotal();

              Console.WriteLine("°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°");
              Console.WriteLine("Itens do pedido:");
              foreach (var doce in pedido.GetDoces())
              {
                  Console.WriteLine($"{doce.getNomeDoce()} - R$ {doce.getPrecoDoce()} x {doce.getQuantidadeDoce()}");
              }
              foreach (var bebida in pedido.GetBebidas())
              {
                Console.Write($"{bebida.getNomeBebida()} - R$ {bebida.getPrecoBebida() x {bebida.getQuantidadeBebida()}");
              }
              foreach (var salgado in pedido.GetSalgados())
              {
                Console.WriteLine($"{salgado.getNomeSalgado() - R$ {salgado.getPrecoSalgado()} x {salgado.getQuantidadeSalgado()} ");
              }
              Console.WriteLine($"Total: R$ {pedido.Total}");
              Console.WriteLine($"Método de pagamento: {pedido.GetMetodoPagamento()}");
              console.WriteLne()
          }
         
       }
  }
}
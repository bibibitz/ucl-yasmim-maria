class Doce 
{
  private string NomeDoce;
  private int PrecoDoce;
  private int QuantidadeDoce;

  plublic Doce(string nomeDoce, int precoDoce)
  {
    this.NomeDoce = nomeDoce;
    this.PrecoDoce = precoDoce;
    QuantidadeDoce = 0;
  }
  public string GetNomeDoce()
  {
       return NomeDoce;
  }
  public void setNomeDoce(string nd)
  {
    NomeDoce = nd;

    
  }
  public int getPrecoDoce()
  {
    return PrecoDoce;
  }
  }
  public void setPrecoDoce(int pd)
  {
    PrecoDoce = pd;
  }


  public int getQuantidadeDoce()
  {
    return QuantidadeDoce;  
  }
  public void setQuantidadeDoce(int qd)
  {
    QuantidadeDoce = qd;
  }
  
}

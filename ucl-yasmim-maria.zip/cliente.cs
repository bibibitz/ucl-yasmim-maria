class Cliente
{
  private string Nome;

  public Cliente(string Nome)
  {
    this.Nome = Nome;
  }
  public string getNome
}
using System;
using System.Collections.Generic;
using Systen.IO;

class Pedido{
  private Cliente Cliente
  private List<doces> doces;
  private List<Bebida> Bebida;
  private List<Salgado> Salgados;
  public decimal Total;
  private String Metododepagamento;


  public Pedido(Cliente cliente, list<Doce> doces,List<Bebidas> Bebida,List<Salgado> Salgados){
    this.Cliente = cliente;
    this.Doces = doces?? new List<Doce>();
    this.Bebidas = bebidas?? new List<Bebida>();
    this.|Salgados = salgados?? new List<Salgado>();
  }
  public Cliente GetCliente(){
    return Cliente;
  }
  public void SetCliente(Cliente cliente){
    Cliente = cliente;
  }
  public List<Doce> GetDoces(){
    return Doces;
  }
  public void AddDoce(Doce doce){
    Doces.Add(doce);
    }
  public List<Bebida> GetBebidas(){
    return Bebidas;
  }
  public void AddBebida(Bebida bebida){
    Bebidas.Add(bebida);
  }
  public List<Salgado> GetSalgadoss(){
    return Salgados;
    }
  public void AddSalgado(Salgado salgado){
    Salgados.Add(salgado);
  }
  public string Get MetodoPagamento(){
    return MetodoPagamento;
  }
  public void CalcularTotal(){
    Total = 0;
    foreach(var doce in Doces){
      Total +=doce.getPrecoDoce() * doce.getQuantidadeDoce();
    }
    foreach(var bebida in Bebidas){
      Total +=bebida.getPrecoBebida() * bebida.getQuantidadeBebida();
  }
    foreach(var salgado in Salgados){
      Total +=salgado.getPrecoSalgado() * salgado.getQuantidadeSalgado();
      }
    }
  public static void SalvarPedido(Pedido pedido){
    using(StreamWriter writer = new StreamWriter("pedidos.txt",true)){
      writer.WriteLine("Cliente:{0}",pedido.Cliente.getNome());
writer.WriteLine("Doces:");
      foreach(var doce in pedido.Doces){
        writer.WriteLine("{0},R$ {1}, {2}",doce.getNomeDoce(),doce.getPrecoDoce(),doce.getQuantidadeDoce());
      }
      
      writer.WriteLine("Bebidas:");
      foreach(var bebida in pedido.Bebidas){
        writer.WriteLine("{0},R$ {1}, {2}",bebida.getNomeBebida(),bebida.getPrecoBebida(),bebida.getQuantidadeBebida());
      }
      writer.WriteLine("Salgadoss:");
      foreach(var salgado in pedido.Salgados){
        writer.WriteLine("{0},R$ {1}, {2}",salgado.getNomeSalgado(),salgado.getPrecoSalgado(),salgado.getQuantidadeSalgado());
        }

    writer.WriteLine("Total: R$ {0}",pedido.Total);
      writer.WriteLine("Método de Pagamento: {0}",MetodoPagamento);
      writer.WriteLine("======================================");
      
    }
  }
  
  



  
}